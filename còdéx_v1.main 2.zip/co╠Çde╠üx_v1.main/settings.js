const settings = {
  packname: 'códéx_v',
  author: 'CŒDĒXTECH & MAGICAL RAMZY',
  botName: "còdéx_v1",
  botOwner: 'SNOWBIRD', // Your name
  ownerNumber: '233549739247 & +233551961429', //Set your number here without + symbol.
  giphyApiKey: 'qnl7ssQChTdPjsKta2Ax2LMaGXz303tq',
  commandMode: "public",
  description: "This is a bot for managing group commands and automating tasks.",
  version: "1.0.0",
};

module.exports = settings;
